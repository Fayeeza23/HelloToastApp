package com.example.hellotoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button button_toast;
    private TextView show_count;
    private Button button_count;
    private int duration;
    private int value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button_toast = findViewById(R.id.button_toast);
        show_count = findViewById(R.id.show_count);
        button_count = findViewById(R.id.button_count);

    }
    public void showToast(View view) {
        String msg = "Hello Toast!";
        Toast toast = Toast.makeText(
                this, msg,duration);
        toast.show();
        value = 0;
        String num = String.valueOf(value);
        show_count.setText(num);
    }

    public void buttonCount(View view) {
        value++;
        String num = String.valueOf(value);
        show_count.setText(num);
    }
}
